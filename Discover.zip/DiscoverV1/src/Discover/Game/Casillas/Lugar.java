/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Discover.Game.Casillas;

/**
 *
 * @author dany
 */
public class Lugar extends Propiedad{

    public Lugar(int propietario, 
                 int precioCompra, 
                 int precioEstancia, 
                 int precioHipoteca, 
                 boolean estado, 
                 int tipo, 
                 int xCoord, 
                 int yCoord, 
                 int ancho, 
                 int alto, 
                 String labelString, 
                 int gradosRotacion) {
        super(propietario, precioCompra, precioEstancia, precioHipoteca, estado, tipo, xCoord, yCoord, ancho, alto, labelString, gradosRotacion);
    }
    
  
    
}
