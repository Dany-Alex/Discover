/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Discover.Game.Casillas;

import java.awt.Color;

/**
 *
 * @author dany
 */
public class Carcel extends Casilla{

    public Carcel(int tipo, int xCoord, int yCoord, int ancho, int alto, String labelString, int gradosRotacion) {
        super(tipo, xCoord, yCoord, ancho, alto, labelString, 0, 0, gradosRotacion, false);
    }


    
   
    
}
