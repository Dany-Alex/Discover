/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Discover.Game.Casillas.Tarjetas;

/**
 *
 * @author dany
 */
public class IrCarcel extends Caminar{

    public IrCarcel(int grupo, int cantidadCopias, String mensaje) {
        super(grupo, cantidadCopias, mensaje);
    }
    

    
}
