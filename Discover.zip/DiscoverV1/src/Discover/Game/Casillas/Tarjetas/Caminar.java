/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Discover.Game.Casillas.Tarjetas;

import Discover.GUI.NuevoTablero;
import Discover.GUI.TableroJuego;
import Discover.Game.Casillas.Casilla;

/**
 *
 * @author dany
 */
public class Caminar extends Tarjeta{

    public Caminar(int grupo, int cantidadCopias, String mensaje) {
        super(grupo, cantidadCopias, mensaje);
    }

 
    
}
